public class ConstantType {
	public static String INT="int";
	public static String UNSIGNED="unsigned";
	public static String LONG="long";
	public static String LONG_UNSIGNED="long_unsigned";
	public static String FLOAT="float";
	public static String DOUBLE="double";
	public static String LONG_DOUBLE="long_double";
	public static String CHAR="char";
	public static String STRING="string";
}
